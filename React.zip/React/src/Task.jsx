import React from "react";
import './Task.css'
function Task() {

    return (
        <>


            <div class="container" >
                <div className="card" id="card1">
                    <p id="pack">Free</p>
                    <p id="price" >$0/month</p>
                    <hr className="line" />
                    <p id="user"><span className="tick-icon">&#10003;</span> Single User</p>
                    <p id="storage"><span className="tick-icon">&#10003;</span> 50GB</p>
                    <p id="project"><span className="tick-icon">&#10003;</span> Unlimited Public Projects</p>
                    <p id="access"><span className="tick-icon">&#10003;</span> Community Access</p>
                    <p id="prproject1"><span className="x-icon">&#10006;</span> Unlimited Private Project</p>
                    <p id="phn1"><span className="x-icon">&#10006;</span> Dedicated Phone Support</p>
                    <p id="subdomain1"><span className="x-icon">&#10006;</span> Free Subdomain</p>
                    <p id="status1"><span className="x-icon">&#10006;</span> Monthly Status Report</p>
                    <button id="btn1" className="btn-primary">Button</button>
                </div>

                <div className="card" id="card2">
                    <p id="pack">Plus</p>
                    <p id="price">$9/month</p>
                    <hr className="line" />
                    <p id="user"><span className="tick-icon">&#10003;</span> 5 User</p>
                    <p id="storage"><span className="tick-icon">&#10003;</span> 50GB</p>
                    <p id="project"><span className="tick-icon">&#10003;</span> Unlimited Public Projects</p>
                    <p id="access"><span className="tick-icon">&#10003;</span> Community Access</p>
                    <p id="prproject2"><span className="tick-icon">&#10003;</span> Unlimited Private Project</p>
                    <p id="phn"><span className="tick-icon">&#10003;</span> Dedicated Phone Support</p>
                    <p id="subdomain"><span className="tick-icon">&#10003;</span> Free Subdomain</p>
                    <p id="status1"><span className="x-icon">&#10006;</span> Monthly Status Report</p>
                    <button id="btn1" className="btn-primary">Button</button>
                </div>

                <div className="card" id="card3">
                    <p id="pack">Pro</p>
                    <p id="price">$49/month</p>
                    <hr className="line" />
                    <p id="user"><span className="tick-icon">&#10003;</span> Unlimited User</p>
                    <p id="storage"><span className="tick-icon">&#10003;</span> 50GB</p>
                    <p id="project"><span className="tick-icon">&#10003;</span> Unlimited Public Projects</p>
                    <p id="access"><span className="tick-icon">&#10003;</span> Community Access</p>
                    <p id="prproject3"><span className="tick-icon">&#10003;</span> Unlimited Private Project</p>
                    <p id="phn"><span className="tick-icon">&#10003;</span> Dedicated Phone Support</p>
                    <p id="subdomain"><span className="tick-icon">&#10003;</span> Free Subdomain</p>
                    <p id="status"><span className="tick-icon">&#10003;</span> Monthly Status Report</p>
                    <button id="btn" className="btn-primary">Button</button>
                </div>


            </div>

        </>
    )
}

export default Task